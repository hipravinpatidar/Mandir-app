// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:flutter_card_swiper/flutter_card_swiper.dart';
//
// class Mandir extends StatefulWidget {
//   const Mandir({super.key});
//
//   @override
//   State<Mandir> createState() => _MandirState();
// }
//
// class _MandirState extends State<Mandir> with TickerProviderStateMixin {
//
//   bool _isFlowerVisible = false;
//   bool _hasFlowerStarted = false;
//   bool _isThaliGifVisible = false;
//   bool _isAartiRotating = false; // New flag for rotation state
//
//   Offset _offset = Offset.zero;
//
//   List<List<dynamic>> images = [
//     ['assets/images/ganesh_ji.png', 'assets/images/ganesh_ji.png', 'assets/images/ganesh_ji.png', 'assets/images/ganesh_ji.png'],
//     ['assets/images/hanuman.png', 'assets/images/hanuman_2.png', 'assets/images/hanuman.png', 'assets/images/hanuman_2.png'],
//     ['assets/images/durga_ma.png', 'assets/images/laxmi_ma.png', 'assets/images/durga_ma.png', 'assets/images/laxmi_ma.png'],
//     ['assets/images/ganesh.png', 'assets/images/ganesh.png', 'assets/images/ganesh.png', 'assets/images/ganesh.png'],
//   ];
//
//   int _currentIndex = 0;
//
//   @override
//   Widget build(BuildContext context) {
//     double screenwidth = MediaQuery.sizeOf(context).width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return DefaultTabController(
//       length: 7,
//       child: Scaffold(
//         appBar: AppBar(
//           backgroundColor: Colors.deepOrange,
//           centerTitle: true,
//           title: Container(
//             height: 60, // adjust the height of the bottom bar
//             width: 200,
//             child: ListView(
//               scrollDirection: Axis.horizontal,
//               children: [
//
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     width: 40, // adjust the size of the circular button
//                     height: 40,
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       border: Border.all(color: Colors.white, width: 2),
//                     ),
//                     child: CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/ganesh.png'),
//                       radius: 20, // adjust the radius to control the size of the circular image
//                     ),
//                   ),
//                 ),
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     width: 40, // adjust the size of the circular button
//                     height: 40,
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       border: Border.all(color: Colors.white, width: 2),
//                     ),
//                     child: CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/krishna.png'),
//                       radius: 20, // adjust the radius to control the size of the circular image
//                     ),
//                   ),
//                 ),
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     width: 40, // adjust the size of the circular button
//                     height: 40,
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       border: Border.all(color: Colors.white, width: 2),
//                     ),
//                     child: CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/ganesh.png'),
//                       radius: 20, // adjust the radius to control the size of the circular image
//                     ),
//                   ),
//                 ),
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     width: 40, // adjust the size of the circular button
//                     height: 40,
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       border: Border.all(color: Colors.white, width: 2),
//                     ),
//                     child: CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/durga.png'),
//                       radius: 20, // adjust the radius to control the size of the circular image
//                     ),
//                   ),
//                 ),
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     width: 40, // adjust the size of the circular button
//                     height: 40,
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       border: Border.all(color: Colors.white, width: 2),
//                     ),
//                     child: CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/ganesh.png'),
//                       radius: 20, // adjust the radius to control the size of the circular image
//                     ),
//                   ),
//                 ),
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     width: 40, // adjust the size of the circular button
//                     height: 40,
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       border: Border.all(color: Colors.white, width: 2),
//                     ),
//                     child: CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/ganesh.png'),
//                       radius: 20, // adjust the radius to control the size of the circular image
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           leading: IconButton(
//             icon: Icon(
//               Icons.person,
//               color: Colors.white,
//             ),
//             onPressed: () {},
//           ),
//           actions: [IconButton(onPressed: (){}, icon: Icon(Icons.add),)],
//
//         ),
//         body: SafeArea(
//           child: Stack(
//             children: [
//
//               Container(
//                 decoration: BoxDecoration(
//                   image: DecorationImage(
//                     image: AssetImage("assets/images/background.jpg"),
//                     fit: BoxFit.fill, // optional
//                   ),
//                 ),
//                 height: 810,
//                 width: double.infinity,
//                 child: Stack(
//                   children: [
//                     Positioned(
//                       bottom: 400,
//                       left: 104,
//                       child: Center(
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//
//                             Image.asset("assets/images/round.gif",height: 200,)
//                           ],
//                         ),
//                       ),
//                     ),
//                     PageView.builder(
//                     onPageChanged: (index) {
//                       _currentIndex = index;
//                     },
//                     itemCount: images.length,
//                     itemBuilder: (context, index) {
//                       return CardSwiper(
//                         backCardOffset: Offset(0, 10),
//                         cardsCount: images[index].length,
//                         cardBuilder: (context, cardIndex, x, y) {
//                           return ClipRRect(
//                             borderRadius: BorderRadius.circular(12),
//                             child: Image.asset(images[index][cardIndex], fit: BoxFit.contain,),
//                           );
//                         },
//                         scale: 0.4,  // Adjust this value to control card scaling (1.0 means no scaling)
//                       );
//                     },
//                   ),
//                   ]
//                 ),
//               ),
//
//               SizedBox(
//                 height: 900,
//                 child: Stack(
//                   children: [
//
//                     Visibility(
//                       visible: _isFlowerVisible,
//                       child: Image.asset('assets/images/flower.gif'),
//                     ),
//
//                     //thaliiiiiii
//                     Center(
//                       child: Padding(
//                         padding: EdgeInsets.only(top: 100),
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             _isThaliGifVisible
//                                 ? Image.asset("assets/images/thali_round.gif",height: 618,)
//                                 : Container(),
//                           ],
//                         ),
//                       ),
//                     ),
//
//                     // SizedBox(height: 370),
//
//                     Positioned(
//                       top: 420,
//                       child: Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                         child: Column(
//                           children: [
//                             GestureDetector(
//                               onTap: (){
//                                 setState(() {
//                                   _isThaliGifVisible = !_isThaliGifVisible; // toggle the variable
//                                 });
//                               },
//                               child: Container(
//                                 child: Image.asset("assets/images/aarti_b.png"),
//                                 width: 50,
//                                 height: 50,
//                                 decoration: BoxDecoration(
//                                   border: Border.all(color: Colors.white, width: 1),
//                                   color: Colors.orange.shade800.withOpacity(0.4), // highlight color
//                                   borderRadius: BorderRadius.circular(300),
//                                 ),
//                               ),
//                             ),
//                             SizedBox(height: 3),
//                             Container(decoration: BoxDecoration(color: Colors.orangeAccent,borderRadius: BorderRadius.circular(10)), child: Text("  Arti  ",style: TextStyle(fontWeight: FontWeight.bold),)),
//                           ],
//                         ),
//                       ),
//                     ),
//
//                     Positioned(
//                       child: Padding(
//                         padding: EdgeInsets.only(top: 505, right: 8,left: 8),
//                         child: Row(
//                           children: [
//
//                             Column(
//                               children: [
//                                 GestureDetector(
//                                   onTap: () {
//                                     setState(() {
//                                       _isFlowerVisible = !_isFlowerVisible;
//                                       if (_isFlowerVisible && !_hasFlowerStarted) {
//                                         _hasFlowerStarted = true;
//                                       }
//                                     });
//                                   },
//                                   child: Container(
//                                     child: Image.asset("assets/images/flower_b.png"),
//                                     width: 50,
//                                     height: 50,
//                                     decoration: BoxDecoration(
//                                       border: Border.all(color: Colors.white, width: 1),
//                                       color: Colors.orange.shade800.withOpacity(0.4), // highlight color
//                                       borderRadius: BorderRadius.circular(300),
//                                     ),
//                                   ),
//                                 ),
//                                 SizedBox(height: 3),
//
//                                 Container(
//
//                                   decoration: BoxDecoration(
//                                       color: Colors.orangeAccent,borderRadius: BorderRadius.circular(10)
//                                   ),
//
//                                   child: Text(" Flower ",
//                                     style: TextStyle(
//                                         fontWeight: FontWeight.bold
//                                     ),
//                                   ),
//
//                                 ),
//                               ],
//                             ),
//
//                             Spacer(),
//
//                           ],
//                         ),
//                       ),
//                     ),
//

//                     Padding(
//                       padding: const EdgeInsets.only(top: 585, left: 8,right: 8),
//                       child: Row(
//                         children: [
//
//                           // Spacer(),
//
//                           Column(
//                             children: [
//                               GestureDetector(
//                                 onTap: (){},
//                                 child: Container(
//                                   child: Image.asset("assets/images/shank.png"),
//                                   width: 50,
//                                   height: 50,
//                                   decoration: BoxDecoration(
//                                     border: Border.all(color: Colors.white, width: 1),
//                                     color: Colors.orange.shade300.withOpacity(0.4), // highlight color
//                                     borderRadius: BorderRadius.circular(300),
//                                   ),
//                                 ),
//                               ),
//                               SizedBox(height: 3),
//
//                               Container(
//
//                                 decoration: BoxDecoration(
//                                     color: Colors.orangeAccent,borderRadius: BorderRadius.circular(10)
//                                 ),
//
//                                 child: Text(" Shank ",
//                                   style: TextStyle(
//                                       fontWeight: FontWeight.bold
//                                   ),
//                                 ),
//
//                               ),
//                             ],
//                           ),
//
//                         ],
//                       ),
//                     ),
//
//                     Positioned(
//                       top: 665,
//                       child: Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                         child: Row(
//                           children: [
//                             GestureDetector(
//                               onTap: (){},
//                               child: Container(
//                                 child: Image.asset("assets/images/sanget_b.png"),
//                                 width: 50,
//                                 height: 50,
//                                 decoration: BoxDecoration(
//                                   border: Border.all(color: Colors.white, width: 1),
//                                   color: Colors.orange.shade800.withOpacity(0.4), // highlight color
//                                   borderRadius: BorderRadius.circular(300),
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//
//                     _isThaliGifVisible
//                         ? Container()
//                         : Positioned(
//                       bottom: 27,
//                       left: 120,
//                       child: Center(
//                         child: GestureDetector(
//                           onTap: (){}, // Rotate when tapped
//                           child: Draggable(
//                             child: Image.asset(
//                               'assets/images/aarti.png',
//                               height: 85,
//                             ),
//                             feedback: Image.asset(
//                               'assets/images/aarti.png',
//                               height: 85,
//                             ),
//                             childWhenDragging: Container(), // Optional
//                             onDragStarted: () {
//                               // Optional callback when drag starts
//                             },
//                             onDragUpdate: (details) {
//                               // Update the position of the image based on the drag update
//                               setState(() {
//                                 _offset = details.globalPosition;
//                               });
//                             },
//                             onDragEnd: (details) {
//                               // Optional callback when drag ends
//                             },
//                           ),
//                         ),
//                       ),
//                     ),
//
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// import 'package:audioplayers/audioplayers.dart';
// import 'package:audioplayers/audioplayers.dart';
// import 'package:audioplayers/audioplayers.dart';
// import 'package:audioplayers/audioplayeraudioplayers.dart';
import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
// import 'package:just_audio/just_audio.dart';

class Mandir extends StatefulWidget {
  const Mandir({super.key});

  @override
  State<Mandir> createState() => _MandirState();
}

class _MandirState extends State<Mandir> with TickerProviderStateMixin {
  bool _isThaliGifVisible = false;

  Offset _offset = Offset.zero;
  int _currentIndex = 0;

  bool isPlaying = false;
  bool isShankPlaying = false;

  bool _isGif1Visible = false;
  bool _isGif2Visible = false;

  List<List<dynamic>> images = [
    [
      'assets/images/ganesh_ji_2.png',
      'assets/images/ganesh_ji_1.png',
      'assets/images/ganesh_ji_2.png',
      'assets/images/ganesh_ji_1.png'
    ],
    [
      'assets/images/hanuman.png',
      'assets/images/hanuman_2.png',
      'assets/images/hanuman.png',
      'assets/images/hanuman_2.png'
    ],
    [
      'assets/images/Durga_1.png',
      'assets/images/Durga_2.png',
      'assets/images/Durga_1.png',
      'assets/images/Durga_2.png'
    ],
    [
      'assets/images/laxmi_1.png',
      'assets/images/laxmi_2.png',
      'assets/images/laxmi_1.png',
      'assets/images/laxmi_2.png'
    ],
  ];

  int _currentBackgroundIndex = 0;
  int _currentToranIndex = 0;
  int _currentThaliIndex = 0;

  // AppBar colors list
  List<Color> appBarColors = [
    Colors.purple,
    Colors.amber,
    Colors.redAccent,
    Colors.blueAccent,
  ];

  // Background images list
  List<String> backgroundImages = [
    'assets/images/background.jpg',
    // 'assets/images/bg_1.png',
    // 'assets/images/bg_2.png',
    // 'assets/images/bg_3.png',
    // 'assets/images/bg_4.png',
  ];

  // Toran images list
  List<String> toranImages = [
    'assets/images/arch_5.png',
    'assets/images/arch_4.png',
    'assets/images/arch_5.png',
  ];

  // Thali images list

  List<String> thaliImages = [
    'assets/images/coper_thali.png',
    'assets/images/golden_thali.png',
    'assets/images/silver_thali.png',
  ];

  //   FLOWERSSSS
  bool _isFlowerVisible = false; // Controls the visibility of the GIF
  bool _hasFlowerStarted =
      false; // To track if the flower animation has started

  void _showFlower() {
    setState(() {
      _isFlowerVisible = true; // Show the GIF
      if (!_hasFlowerStarted) {
        _hasFlowerStarted = true; // Mark that the flower animation has started
      }
    });

    // Start a timer to hide the flower GIF after 2 seconds
    Timer(Duration(seconds: 4), () {
      setState(() {
        _isFlowerVisible = false; // Hide the GIF after 2 seconds
      });
    });
  }

  // BELL-11111   List of images for
  final String bellImage =
      'assets/images/Bell_1.png'; // Path to your bell image
  final String bellGif = 'assets/images/bell_video.gif'; // Path to your GIF
  bool _showGif = false; // State to track which image to show


  // BELL-222222   List of images
  final String bellImages =
      'assets/images/bell_2.png'; // Path to your bell image
  final String bellGifs = 'assets/images/bell_video.gif'; // Path to your GIF
  bool _showGifs = false; // State to track which image to show

  void _toggleImage(bool isToggle) {
    setState(() {
      _showGif = isToggle; // Show the GIF
    });

    // Start a timer to switch back to the bell image after 1 second
    Timer(Duration(milliseconds: 1000), () {
      setState(() {
        _showGif = false; // Switch back to the bell image
      });
    });
  }

  void _toggleImages(bool isToggle) {
    setState(() {
      _showGifs = isToggle; // Show the GIF
    });

    // Start a timer to switch back to the bell image after 1 second
    Timer(Duration(milliseconds: 1000), () {
      setState(() {
        _showGifs = false; // Switch back to the bell image
      });
    });
  }

  final player1 = AudioPlayer();
  final player2 = AudioPlayer();

  final artiPlayer = AudioPlayer();
  final shankPlayer = AudioPlayer();


  @override
  void initState() {
    super.initState();

    // Listen to when the audio has completed playing
    artiPlayer.onPlayerComplete.listen((event) {
      // Automatically stop the player and toggle the state
      artiPlayer.play(AssetSource("images/arti_audio.mp3"));
      _toggleImage(true);
      _toggleImages(true);
    });
  }

  @override
  void dispose() {
    super.dispose();
    player1.dispose();
    shankPlayer.dispose();
    artiPlayer.dispose();
    player2.dispose();
  }

  @override
  Widget build(BuildContext context) {

    double screenwidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return DefaultTabController(
      length: 7,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: appBarColors[_currentBackgroundIndex],
          centerTitle: true,
          title: Container(
            child: Text(
              "MANDIR",
              style:
                  TextStyle(fontWeight: FontWeight.bold, color: Colors.orange),
            ),
            // child: ListView(
            //   scrollDirection: Axis.horizontal,
            //   children: [
            //
            //     GestureDetector(
            //       onTap: () {},
            //       child: Container(
            //         width: 40, // adjust the size of the circular button
            //         height: 40,
            //         decoration: BoxDecoration(
            //           shape: BoxShape.circle,
            //           border: Border.all(color: Colors.white, width: 2),
            //         ),
            //         child: CircleAvatar(
            //           backgroundImage: AssetImage('assets/images/ganesh.png'),
            //           radius: 20, // adjust the radius to control the size of the circular image
            //         ),
            //       ),
            //     ),
            //     GestureDetector(
            //       onTap: () {},
            //       child: Container(
            //         width: 40, // adjust the size of the circular button
            //         height: 40,
            //         decoration: BoxDecoration(
            //           shape: BoxShape.circle,
            //           border: Border.all(color: Colors.white, width: 2),
            //         ),
            //         child: CircleAvatar(
            //           backgroundImage: AssetImage('assets/images/krishna.png'),
            //           radius: 20, // adjust the radius to control the size of the circular image
            //         ),
            //       ),
            //     ),
            //     GestureDetector(
            //       onTap: () {},
            //       child: Container(
            //         width: 40, // adjust the size of the circular button
            //         height: 40,
            //         decoration: BoxDecoration(
            //           shape: BoxShape.circle,
            //           border: Border.all(color: Colors.white, width: 2),
            //         ),
            //         child: CircleAvatar(
            //           backgroundImage: AssetImage('assets/images/ganesh.png'),
            //           radius: 20, // adjust the radius to control the size of the circular image
            //         ),
            //       ),
            //     ),
            //     GestureDetector(
            //       onTap: () {},
            //       child: Container(
            //         width: 40, // adjust the size of the circular button
            //         height: 40,
            //         decoration: BoxDecoration(
            //           shape: BoxShape.circle,
            //           border: Border.all(color: Colors.white, width: 2),
            //         ),
            //         child: CircleAvatar(
            //           backgroundImage: AssetImage('assets/images/krishna.png'),
            //           radius: 20, // adjust the radius to control the size of the circular image
            //         ),
            //       ),
            //     ),
            //     GestureDetector(
            //       onTap: () {},
            //       child: Container(
            //         width: 40, // adjust the size of the circular button
            //         height: 40,
            //         decoration: BoxDecoration(
            //           shape: BoxShape.circle,
            //           border: Border.all(color: Colors.white, width: 2),
            //         ),
            //         child: CircleAvatar(
            //           backgroundImage: AssetImage('assets/images/ganesh.png'),
            //           radius: 20, // adjust the radius to control the size of the circular image
            //         ),
            //       ),
            //     ),
            //   ],
            // ),
          ),
          leading: IconButton(
            icon: Icon(
              Icons.person,
              color: Colors.white,
            ),
            onPressed: () {},
          ),
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.add),
            )
          ],
        ),
        body: SafeArea(
          child: Stack(
            children: [
              Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(backgroundImages[
                          _currentBackgroundIndex]), // Use the same asset path
                      fit: BoxFit.fill,
                    ),
                  ),
                  height: 810,
                  width: double.infinity,
                  child: Stack(
                    children: [
                      //     TORAN
                      Container(
                        height: screenHeight * 0.204,
                        width: double.infinity,
                        child: Image.asset(
                          toranImages[_currentToranIndex],
                          fit: BoxFit.fill,
                        ),
                      ),

                      Visibility(
                        visible: _isFlowerVisible,
                        child: Image.asset(
                            'assets/images/flower.gif'), // Show the GIF
                      ),
                    ],
                  )),

              //  CARD  SWIPER
              PageView.builder(
                onPageChanged: (index) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
                itemCount: images.length,
                itemBuilder: (context, index) {
                  return CardSwiper(
                    backCardOffset: Offset(0, 10),
                    cardsCount: images[index].length,
                    cardBuilder: (context, cardIndex, x, y) {
                      return ClipRRect(
                        // borderRadius: BorderRadius.circular(12),
                        child: Image.asset(
                          images[index][cardIndex],
                          fit: BoxFit.contain,
                        ),
                      );
                    },
                    scale:
                        0.4, // Adjust this value to control card scaling (1.0 means no scaling)
                  );
                },
              ),


              //  BELL-11111
              if (_showGif)
                Positioned(
                  bottom: screenHeight * 0.617,
                  left: screenwidth * 0.025,
                  child: GestureDetector(
                    onTap: () {
                      _toggleImage(true);
                      },
                    child: Image.asset(
                      bellGif, // Show the GIF
                      height: 100,
                    ),
                  ),
                )
              else
                Positioned(
                  bottom: screenHeight * 0.617,
                  left: screenwidth * 0.095,
                  child: GestureDetector(
                    onTap: () {
                      playBellFirst();
                      _toggleImage(true);
                    },
                    child: Image.asset(
                      bellImage, // Show the original bell image
                      height: 100,
                    ),
                  ),
                ),

              //  BELL-222222
              if (_showGifs)
                Positioned(
                  bottom: screenHeight * 0.617,
                  left: screenwidth * 0.73,
                  child: GestureDetector(
                    onTap: () {
                      _toggleImages(true);
                    },
                    child: Image.asset(
                      bellGifs, // Show the GIF
                      height: 100,
                    ),
                  ),
                )
              else
                Positioned(
                  bottom: screenHeight * 0.617,
                  left: screenwidth * 0.80,
                  child: GestureDetector(
                    onTap: () {
                      _toggleImages(true);
                       playBellSecond();
                    },
                    child: Image.asset(
                      bellImages, // Show the original bell image
                      height: 100,
                    ),
                  ),
                ),



              // Overlay for buttons
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                child: Stack(
                  children: [
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 100),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _isThaliGifVisible
                                ? Image.asset(
                                    "assets/images/thali_round.gif",
                                    height: 550,
                                  )
                                : Container(),
                          ],
                        ),
                      ),
                    ),

                    // Positioned(
                    //   top: 350,
                    //   left: 15,
                    //   child: ElevatedButton(
                    //       onPressed: (){
                    //         playSound();
                    //       },
                    //       child: Text("please press me"),
                    //   ),
                    // ),

                    Positioned(
                      top: 400,
                      left: 8,
                      child: Column(
                        children: [
                          IgnorePointer(
                            ignoring:
                                false, // Allow interaction with the buttons
                            child: GestureDetector(
                              onTap:
                                  _showFlower, // Call the function to show the flower GIF
                              child: Container(
                                child: Image.asset(
                                    "assets/images/flower_b.png"), // Flower button
                                width: 45,
                                height: 45,
                                decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.white, width: 1),
                                  color: Colors.orange.shade800
                                      .withOpacity(0.4), // Highlight color
                                  borderRadius: BorderRadius.circular(300),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 3),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.orangeAccent,
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              " flower ",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),

                    Positioned(
                      top: 480,
                      left: 8,
                      child: Column(
                        children: [
                          IgnorePointer(
                            ignoring:
                                false, // Allow interaction with the buttons
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  toggleArti();
                                  _isFlowerVisible = !_isFlowerVisible;
                                  if (_isFlowerVisible && !_hasFlowerStarted) {
                                    _hasFlowerStarted = true;
                                  }
                                  _isThaliGifVisible =
                                      !_isThaliGifVisible;

                                  if(isPlaying = true){
                                    _toggleImages(true); // Call your custom toggle function
                                    _toggleImage(true);// Call the state toggle function
                                  }
                                });
                              },
                              child: Container(
                                child: Image.asset("assets/images/aarti_b.png"),
                                width: 45,
                                height: 45,
                                decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.white, width: 1),
                                  color: Colors.orange.shade800
                                      .withOpacity(0.4), // highlight color
                                  borderRadius: BorderRadius.circular(300),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 3),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.orangeAccent,
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              "  aarti  ",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.only(top: 556, left: 8, right: 8),
                      child: Row(
                        children: [
                          Column(
                            children: [
                              // Text(_showGif ? 'Show Original Image' : 'Show Bell GIF'),
                              GestureDetector(
                                onTap: () {
                                  setState(() {
                                    playShank();
                                  });
                                },
                                child: Container(
                                  child: Image.asset("assets/images/shank.png"),
                                  width: 45,
                                  height: 45,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.white, width: 1),
                                    color: Colors.orange.shade300
                                        .withOpacity(0.4), // highlight color
                                    borderRadius: BorderRadius.circular(300),
                                  ),
                                ),
                              ),
                              SizedBox(height: 3),

                              Container(
                                decoration: BoxDecoration(
                                    color: Colors.orangeAccent,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Text(
                                  " Song ",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    Positioned(
                      top: 635,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Row(
                          children: [
                            GestureDetector(
                              onTap: () {
                                // Change background and images on tap
                                setState(() {
                                  _currentBackgroundIndex =
                                      (_currentBackgroundIndex + 1) %
                                          backgroundImages.length;
                                  _currentToranIndex =
                                      (_currentToranIndex + 1) %
                                          toranImages.length;
                                  // _currentShubhIndex = (_currentShubhIndex + 1) % shubhImages.length;
                                  // _currentLabhIndex = (_currentLabhIndex + 1) % labhImages.length;
                                  _currentThaliIndex =
                                      (_currentThaliIndex + 1) %
                                          thaliImages.length;
                                });
                              },
                              child: Container(
                                child:
                                    Image.asset("assets/images/sanget_b.png"),
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.white, width: 1),
                                  color: Colors.orange.shade800
                                      .withOpacity(0.4), // highlight color
                                  borderRadius: BorderRadius.circular(300),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    _isThaliGifVisible
                        ? Container()
                        : Positioned(
                            bottom: 40,
                            left: 140,
                            child: Center(
                              child: GestureDetector(
                                onTap: () {}, // Rotate when tapped
                                child: Draggable(
                                  child: Image.asset(
                                    thaliImages[_currentThaliIndex],
                                    // width: 100,
                                    height: 65,
                                  ),
                                  feedback: Image.asset(
                                    'assets/images/aarti.png',
                                    height: 75,
                                  ),
                                  childWhenDragging: Container(), // Optional
                                  onDragStarted: () {
                                    // Optional callback when drag starts
                                  },
                                  onDragUpdate: (details) {
                                    // Update the position of the image based on the drag update
                                    setState(() {
                                      _offset = details.globalPosition;
                                    });
                                  },
                                  onDragEnd: (details) {
                                    // Optional callback when drag ends
                                  },
                                ),
                              ),
                            ),
                          ),
                    // Other buttons...
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> playShank() async {
    String audiopath = "images/_shank.mp3";


    if (isShankPlaying) {
      // Stop the audio if it's currently playing
      await shankPlayer.stop();
      setState(() {
        isShankPlaying = false;
      });
    } else {
      // Play the audio if it's not playing
      await shankPlayer.play(AssetSource(audiopath));
      setState(() {
        isShankPlaying = true;
      });
    }

  }


  Future<void> playBellFirst() async {
    String audiopath = "images/mybell.mp3";
    await player1.stop(); // Stop the current playback
    await player1.play(AssetSource(audiopath)); // Restart the sound
  }

  Future<void> playBellSecond() async {
    String audiopath = "images/mybell.mp3";
    await player2.stop(); // Stop the current playback
    await player2.play(AssetSource(audiopath)); // Restart the sound
  }



  // Future<void> playBellFirst() async {
  //   String audiopath = "images/mybell.mp3";
  //   await player1.play(AssetSource(audiopath));
  // }
  //
  // Future<void> playBellSecond() async {
  //   String audiopath = "images/mybell.mp3";
  //   await player2.play(AssetSource(audiopath));
  // }

  Future<void> toggleArti() async {
    String audioPath = "images/arti_audio.mp3";

    if (isPlaying) {
      // Stop the audio if it's currently playing
      await artiPlayer.stop();
      setState(() {
        isPlaying = false;
      });
    } else {
      // Play the audio if it's not playing
      await artiPlayer.play(AssetSource(audioPath));
      setState(() {
        isPlaying = true;
      });
    }
  }

}
