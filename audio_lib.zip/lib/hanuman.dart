//
// // import 'package:flutter/material.dart';
// // import 'package:audioplayers/audioplayers.dart';
// //
// // class HanumanChalisaScreen extends StatefulWidget {
// //   @override
// //   _HanumanChalisaScreenState createState() => _HanumanChalisaScreenState();
// // }
// //
// // class _HanumanChalisaScreenState extends State<HanumanChalisaScreen> {
// //   AudioPlayer _audioPlayer = AudioPlayer();
// //   bool isPlaying = false;
// //   Duration currentPosition = Duration.zero;
// //   Duration totalDuration = Duration.zero;
// //
// //   int currentLineIndex = 0;
// //
// //   final chalisaData = [
// //     {
// //       "text": "श्रीगुरु चरन सरोज रज, निज मनु मुकुरु सुधारि।",
// //       "image": "assets/images/hanuman.png"
// //     },
// //     {
// //       "text": "बरनऊं रघुबर बिमल जसु, जो दायकु फल चारि।।",
// //       "image": "assets/images/line2.jpg"
// //     },
// //     {
// //       "text": "बुद्धिहीन तनु जानिके, सुमिरौं पवन-कुमार।",
// //       "image": "assets/images/line3.jpg"
// //     },
// //     {
// //       "text": "बल बुधि विद्या देहु मोहिं, हरहु कलेश विकार।।",
// //       "image": "assets/images/line4.jpg"
// //     },
// //   ];
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //
// //     _audioPlayer.onPositionChanged.listen((position) {
// //       setState(() {
// //         currentPosition = position;
// //         _syncWithAudio(position);
// //       });
// //     });
// //
// //     _audioPlayer.onDurationChanged.listen((duration) {
// //       setState(() {
// //         totalDuration = duration;
// //       });
// //     });
// //   }
// //
// //   void _syncWithAudio(Duration position) {
// //     int seconds = position.inSeconds;
// //     if (seconds < 5) {
// //       setState(() {
// //         currentLineIndex = 0;
// //       });
// //     } else if (seconds < 10) {
// //       setState(() {
// //         currentLineIndex = 1;
// //       });
// //     } else if (seconds < 15) {
// //       setState(() {
// //         currentLineIndex = 2;
// //       });
// //     } else {
// //       setState(() {
// //         currentLineIndex = 3;
// //       });
// //     }
// //   }
// //
// //   void _toggleAudio() async {
// //     if (isPlaying) {
// //       await _audioPlayer.pause();
// //     } else {
// //       await _audioPlayer.play(AssetSource("audio/hanuman_chalisa.mp3"));
// //     }
// //     setState(() {
// //       isPlaying = !isPlaying;
// //     });
// //   }
// //
// //   @override
// //   void dispose() {
// //     _audioPlayer.dispose();
// //     super.dispose();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       body: Stack(
// //         children: [
// //           // Background
// //           Positioned.fill(
// //             child: Image.asset(
// //               'assets/images/background.jpg',
// //               fit: BoxFit.cover,
// //             ),
// //           ),
// //           // Gradient overlay
// //           Container(
// //             decoration: BoxDecoration(
// //               gradient: LinearGradient(
// //                 colors: [Colors.orange.withOpacity(0.9), Colors.transparent],
// //                 begin: Alignment.topCenter,
// //                 end: Alignment.bottomCenter,
// //               ),
// //             ),
// //           ),
// //           SafeArea(
// //             child: Column(
// //               children: [
// //                 // Header with Hanuman Ji image
// //                 Padding(
// //                   padding: const EdgeInsets.all(16.0),
// //                   child: Center(
// //                     child: CircleAvatar(
// //                       radius: 60,
// //                       backgroundImage: AssetImage("assets/images/hanuman.png"),
// //                       backgroundColor: Colors.transparent,
// //                     ),
// //                   ),
// //                 ),
// //                 // Stanza display
// //                 Expanded(
// //                   child: PageView.builder(
// //                     controller: PageController(initialPage: currentLineIndex),
// //                     itemCount: chalisaData.length,
// //                     onPageChanged: (index) {
// //                       setState(() {
// //                         currentLineIndex = index;
// //                       });
// //                     },
// //                     itemBuilder: (context, index) {
// //                       final stanza = chalisaData[index];
// //                       return Padding(
// //                         padding: const EdgeInsets.all(16.0),
// //                         child: Column(
// //                           crossAxisAlignment: CrossAxisAlignment.center,
// //                           children: [
// //                             Expanded(
// //                               child: Image.asset(
// //                                 stanza["image"]!,
// //                                 fit: BoxFit.cover,
// //                               ),
// //                             ),
// //                             SizedBox(height: 16),
// //                             Text(
// //                               stanza["text"]!,
// //                               textAlign: TextAlign.center,
// //                               style: TextStyle(
// //                                 fontSize: 24,
// //                                 fontWeight: FontWeight.bold,
// //                                 color: index == currentLineIndex
// //                                     ? Colors.orange
// //                                     : Colors.white,
// //                               ),
// //                             ),
// //                           ],
// //                         ),
// //                       );
// //                     },
// //                   ),
// //                 ),
// //                 // Audio Controls
// //                 Padding(
// //                   padding: const EdgeInsets.symmetric(vertical: 16.0),
// //                   child: Row(
// //                     mainAxisAlignment: MainAxisAlignment.spaceAround,
// //                     children: [
// //                       IconButton(
// //                         icon: Icon(Icons.skip_previous,
// //                             size: 36, color: Colors.white),
// //                         onPressed: () {},
// //                       ),
// //                       IconButton(
// //                         icon: Icon(
// //                           isPlaying ? Icons.pause : Icons.play_arrow,
// //                           size: 48,
// //                           color: Colors.white,
// //                         ),
// //                         onPressed: _toggleAudio,
// //                       ),
// //                       IconButton(
// //                         icon: Icon(Icons.skip_next,
// //                             size: 36, color: Colors.white),
// //                         onPressed: () {},
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //                 // Progress Bar
// //                 Slider(
// //                   value: currentPosition.inSeconds.toDouble(),
// //                   max: totalDuration.inSeconds.toDouble(),
// //                   onChanged: (value) {
// //                     _audioPlayer.seek(Duration(seconds: value.toInt()));
// //                   },
// //                   activeColor: Colors.orange,
// //                   inactiveColor: Colors.white.withOpacity(0.6),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }
//
//
// import 'package:flutter/material.dart';
// import 'package:audioplayers/audioplayers.dart';
//
// class HanumanChalisaScreen extends StatefulWidget {
//   @override
//   _HanumanChalisaScreenState createState() => _HanumanChalisaScreenState();
// }
//
// class _HanumanChalisaScreenState extends State<HanumanChalisaScreen> {
//   AudioPlayer _audioPlayer = AudioPlayer();
//   bool isPlaying = false;
//   Duration currentPosition = Duration.zero;
//   Duration totalDuration = Duration.zero;
//
//   int currentLineIndex = 0;
//
//   final chalisaData = [
//     {
//       "text": "श्रीगुरु चरन सरोज रज, निज मनु मुकुरु सुधारि।",
//       "image": "assets/images/hanuman.png"
//     },
//     {
//       "text": "बरनऊं रघुबर बिमल जसु, जो दायकु फल चारि।।",
//       "image": "assets/images/line2.jpg"
//     },
//     {
//       "text": "बुद्धिहीन तनु जानिके, सुमिरौं पवन-कुमार।",
//       "image": "assets/images/line3.jpg"
//     },
//     {
//       "text": "बल बुधि विद्या देहु मोहिं, हरहु कलेश विकार।।",
//       "image": "assets/images/line4.jpg"
//     },
//   ];
//
//   @override
//   void initState() {
//     super.initState();
//
//     _audioPlayer.onPositionChanged.listen((position) {
//       setState(() {
//         currentPosition = position;
//         _syncWithAudio(position);
//       });
//     });
//
//     _audioPlayer.onDurationChanged.listen((duration) {
//       setState(() {
//         totalDuration = duration;
//       });
//     });
//   }
//
//   void _syncWithAudio(Duration position) {
//     int seconds = position.inSeconds;
//     if (seconds < 5) {
//       setState(() {
//         currentLineIndex = 0;
//       });
//     } else if (seconds < 10) {
//       setState(() {
//         currentLineIndex = 1;
//       });
//     } else if (seconds < 15) {
//       setState(() {
//         currentLineIndex = 2;
//       });
//     } else {
//       setState(() {
//         currentLineIndex = 3;
//       });
//     }
//   }
//
//   void _toggleAudio() async {
//     if (isPlaying) {
//       await _audioPlayer.pause();
//     } else {
//       await _audioPlayer.play(AssetSource("audio/hanuman_chalisa.mp3"));
//     }
//     setState(() {
//       isPlaying = !isPlaying;
//     });
//   }
//
//   @override
//   void dispose() {
//     _audioPlayer.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         children: [
//           // Background
//           Positioned.fill(
//             child: Image.asset(
//               'assets/images/background.jpg',
//               fit: BoxFit.cover,
//             ),
//           ),
//           // Gradient overlay
//           Container(
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 colors: [Colors.orange.withOpacity(0.9), Colors.black54],
//                 begin: Alignment.topCenter,
//                 end: Alignment.bottomCenter,
//               ),
//             ),
//           ),
//           SafeArea(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 // Header with Hanuman Ji image
//                 Padding(
//                   padding: const EdgeInsets.only(top: 24.0),
//                   child: CircleAvatar(
//                     radius: 60,
//                     backgroundImage: AssetImage("assets/images/hanuman.png"),
//                     backgroundColor: Colors.transparent,
//                   ),
//                 ),
//                 SizedBox(height: 16),
//                 Text(
//                   "हनुमान चालीसा",
//                   style: TextStyle(
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.orangeAccent,
//                   ),
//                 ),
//                 SizedBox(height: 16),
//                 // Stanza display
//                 Expanded(
//                   child: PageView.builder(
//                     controller: PageController(initialPage: currentLineIndex),
//                     itemCount: chalisaData.length,
//                     onPageChanged: (index) {
//                       setState(() {
//                         currentLineIndex = index;
//                       });
//                     },
//                     itemBuilder: (context, index) {
//                       final stanza = chalisaData[index];
//                       return Padding(
//                         padding: const EdgeInsets.all(16.0),
//                         child: Column(
//                           children: [
//                             Expanded(
//                               child: Image.asset(
//                                 stanza["image"]!,
//                                 fit: BoxFit.cover,
//                               ),
//                             ),
//                             SizedBox(height: 16),
//                             Text(
//                               stanza["text"]!,
//                               textAlign: TextAlign.center,
//                               style: TextStyle(
//                                 fontSize: 22,
//                                 fontWeight: FontWeight.bold,
//                                 color: index == currentLineIndex
//                                     ? Colors.orangeAccent
//                                     : Colors.white,
//                               ),
//                             ),
//                           ],
//                         ),
//                       );
//                     },
//                   ),
//                 ),
//                 // Audio Controls
//                 Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 16.0),
//                   child: GestureDetector(
//                     onTap: _toggleAudio,
//                     child: CircleAvatar(
//                       radius: 36,
//                       backgroundColor: Colors.orangeAccent,
//                       child: Icon(
//                         isPlaying ? Icons.pause : Icons.play_arrow,
//                         size: 36,
//                         color: Colors.white,
//                       ),
//                     ),
//                   ),
//                 ),
//                 // Progress Indicator
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 32.0),
//                   child: LinearProgressIndicator(
//                     value: totalDuration.inSeconds == 0
//                         ? 0
//                         : currentPosition.inSeconds / totalDuration.inSeconds,
//                     backgroundColor: Colors.white24,
//                     color: Colors.orangeAccent,
//                   ),
//                 ),
//                 SizedBox(height: 16),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
